import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <div className='header'>
        <h2>
          <a href="/">토익 영단어(고급)</a>
        </h2>
        <div className='menu'>
          <a href="/create_word" className='link'>단어추가</a>
          <a href="#" className='link'>Day추가</a>
        </div>
      </div>
    );
  }
}

export default Header;