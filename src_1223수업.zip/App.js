import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './Header';
import DayList from './DayList';
import Day from './Day';

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      <Header />
      <Routes>
        <Route path="/" element={<DayList />} />
        <Route path="day/:day" element={<Day />} />
      </Routes>
    </div>
    </BrowserRouter>
  );
}

export default App;
