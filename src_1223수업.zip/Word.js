import {useState} from 'react'

export default function Word(){
  return(
    <tr>
      <td>{word.eng}</td>
      <td>{word.kor}</td>
    </tr>
  )
}